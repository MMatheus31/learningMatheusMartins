package br.com.aulaapi.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity(name="AEYECOLOR")
public class AEyeColor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "AEYECOLOR_ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "PEOPLE_ID")
    @JsonBackReference
    private People peopleSWAPI;

    @ManyToOne
    @JoinColumn(name = "ACOLOR_ID")
    @JsonBackReference
    private AColor colorSWAPI;


}
