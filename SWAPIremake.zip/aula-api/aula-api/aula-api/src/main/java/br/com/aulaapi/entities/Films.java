package br.com.aulaapi.entities;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

@Entity(name="FILMS")
public class Films {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="FILMS_ID")
    private Integer id;

    @Column(name="FILMS_TITLE", nullable = false)
    private String title;

    @Column(name="FILMS_EPISODENUMBER")
    private String episodenumber;

    @Column(name="FILMS_OPENINGCRAWL")
    private String openingcrawl;

    @Column(name="FILMS_DIRECTOR", nullable = false)
    private String director;

    @Column(name="FILMS_PRODUCER", nullable = false)
    private String producer;

    @Column(name="FILMS_RELEASEDATE", nullable = false)
    private String releasedate;

    @Column(name="FILMS_CREATED")
    @DateTimeFormat
    private String filmscreated;

    @Column(name="FILMS_EDITED")
    @DateTimeFormat
    private String filmessedited;



}
