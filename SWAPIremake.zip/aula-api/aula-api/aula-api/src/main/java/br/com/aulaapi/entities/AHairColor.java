package br.com.aulaapi.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity(name="AHAIRCOLOR")
public class AHairColor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "AHAIRCOLOR_ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "PEOPLE_ID")
    @JsonBackReference
    private People peopleSWAPI;

    @ManyToOne
    @JoinColumn(name = "ACOLOR_ID")
    @JsonBackReference
    private AColor colorSWAPI;
}
