package br.com.aulaapi.entities;


import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

@Entity(name="STARSHIPS")
public class Starships {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="STARSHIPS_ID")
    private Integer id;

    @Column(name="STARSHIPS_NAME")
    private String name;

    @Column(name="STARSHIPS_MODEL", nullable = false)
    private String model;

    @Column(name="STARSHIPS_CLASS", nullable = false)
    private String ssclass;

    @Column(name="STARSHIPS_MANUFACTURER")
    private String  manufactures;

    @Column(name="STARSHIPS_LENGHT")
    private Float lenght;

    @Column(name="STARSHIPS_COSTINCREDITS")
    private Float costincredits;

    @Column(name="STARSHIPS_CREW")
    private Integer crew;

    @Column(name="STARSHIPS_PASSENGERS", nullable = false)
    private Integer passengers;

    @Column(name="VEHICLES_MAXATHMOSPHERINGSPEED", nullable = false)
    private Float ssma_speed ;

    @Column(name="VEHICLES_HYPERDRIVERATING", nullable = false)
    private String hd_rating ;

    @Column(name="VEHICLES_MGLT", nullable = false)
    private Float mglt;

    @Column(name="VEHICLES_CARGOCAPACITY", nullable = false)
    private Float cargocapacity;

    @Column(name="VEHICLES_CONSUMABLES")
    private Float consumables;

    @Column(name="VEHICLES_CREATED")
    @DateTimeFormat
    private String starshipscreated;

    @Column(name="VEHICLES_EDITED")
    @DateTimeFormat
    private String starshipsedited;

}
