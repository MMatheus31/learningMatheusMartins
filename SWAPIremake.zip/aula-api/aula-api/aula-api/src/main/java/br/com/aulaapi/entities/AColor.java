package br.com.aulaapi.entities;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity(name = "ACOLOR")
public class AColor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ACOLOR_ID")
    private  Long id;

    @Column(name = "ACOLOR_NAME", nullable = false)
    private String name;

    @OneToMany(mappedBy = "colorSWAPI", cascade = {CascadeType.ALL})
    private Set<AEyeColor> eyeColorSWAPI;

    @OneToMany(mappedBy = "colorSWAPI", cascade = {CascadeType.ALL})
    private Set<AHairColor> hairColorSWAPI;

    @OneToMany(mappedBy = "colorSWAPI", cascade = {CascadeType.ALL})
    private Set<ASkinColor> skinColorSWAPI;

}
