package br.com.aulaapi.controllers;

import br.com.aulaapi.entities.People;
import br.com.aulaapi.dto.PeopleDTO;
import br.com.aulaapi.services.ServiceSWAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping({"/people"})
public class ControllerSWAPI {
    @Autowired
    ServiceSWAPI serviceSWAPI;

    @GetMapping
    @ResponseBody
    public List<PeopleDTO> searchPeople() {
        return serviceSWAPI.searchPeople();
    }

    @PostMapping
    public People createPeople(@RequestBody People peopleSWAPI) {
        return serviceSWAPI.createPeople(peopleSWAPI);
   }


    @GetMapping(path = "{id}")
    public String readPeople(@PathVariable Long id) {
        return "SWAPI - PERSONAGENS: " + serviceSWAPI.searchPeople();
    }

    @PutMapping
    @ResponseBody
    public People updatePeople(@RequestBody People peopleSWAPI) {
        return serviceSWAPI.updatePeople(peopleSWAPI);
    }

    @DeleteMapping({"/{id}"})
    public People deletePeople(@PathVariable Long id) {
        serviceSWAPI.deletePeople(id);
        return null;
    }
}
