package br.com.aulaapi.entities;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

@Entity(name="VEHICLES")
public class Vehicles {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="VEHICLES_ID")
    private Integer id;

    @Column(name="VEHICLES_NAME")
    private String name;

    @Column(name="VEHICLES_MODEL", nullable = false)
    private String model;

    @Column(name="VEHICLES_CLASS", nullable = false)
    private String vclass;

    @Column(name="VEHICLES_MANUFACTURER")
    private String  manufactures;

    @Column(name="VEHICLES_LENGHT")
    private Float lenght;

    @Column(name="VEHICLES_COSTINCREDITS")
    private Float costincredits;

    @Column(name="VEHICLES_CREW")
    private Integer crew;

    @Column(name="VEHICLES_PASSENGERS", nullable = false)
    private Integer passengers;

    @Column(name="VEHICLES_MAXATHMOSPHERINGSPEED", nullable = false)
    private Float vma_speed ;

    @Column(name="VEHICLES_CARGOCAPACITY", nullable = false)
    private Float cargocapacity;

    @Column(name="VEHICLES_CONSUMABLES")
    private Float consumables;

    @Column(name="VEHICLES_CREATED")
    @DateTimeFormat
    private String vehiclescreated;

    @Column(name="VEHICLES_EDITED")
    @DateTimeFormat
    private String vehiclesedited;

}
