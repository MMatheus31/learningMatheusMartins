package br.com.aulaapi.entities;

import javax.persistence.*;
import java.util.Date;

@Entity
public class PBirthYear {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PBIRTHYEAR_ID")
    private Long id;

    @Column(name = "PBIRTHYEAR_YEAR")
    private Date year;

    @Column(name = "PBIRTHYEAR_PERIOD", nullable = false)
    private String period;

    @OneToOne
    @JoinColumn(name ="PEOPLE_ID")
    private People people;

}
