package br.com.aulaapi.Threads;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class RelogioThread implements Runnable {

    public class ReminderBD extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Bom Dia!");
        }
    }

    public class ReminderBT extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Boa Tarde!");
        }
    }

    public class ReminderBN extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Boa Noite!");
        }
    }

    @Override
    public void run() {

        Timer timer;

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 24);
        calendar.set(Calendar.SECOND, 30);
        Date timer1 = calendar.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBD(), timer1);

        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.HOUR_OF_DAY, 11);
        calendar2.set(Calendar.MINUTE, 24);
        calendar2.set(Calendar.SECOND, 40);
        Date timer2 = calendar2.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBT(), timer2);

        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(Calendar.HOUR_OF_DAY, 11);
        calendar3.set(Calendar.MINUTE, 24);
        calendar3.set(Calendar.SECOND, 50);
        Date timer3 = calendar3.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBN(), timer3);

    }

}





//        int segundos = 0;
//
//
//        while (true) {
//
//            try {
//                if(segundos%25 == 0) {
//                    System.out.println(new Date());
//
//                }
//                segundos++;
//                Thread.sleep(900);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//    }