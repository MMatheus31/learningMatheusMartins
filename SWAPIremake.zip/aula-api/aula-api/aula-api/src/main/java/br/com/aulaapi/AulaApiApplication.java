package br.com.aulaapi;

import br.com.aulaapi.Threads.RelogioThread;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaApiApplication {

	public static void main(String[] args) {
		RelogioThread relogioThread = new RelogioThread();
		Thread thread = new Thread(relogioThread);
		thread.start();

		{SpringApplication.run(AulaApiApplication.class, args);}

	}
}
