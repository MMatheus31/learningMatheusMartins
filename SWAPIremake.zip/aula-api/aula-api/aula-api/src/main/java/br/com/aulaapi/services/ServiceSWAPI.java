package br.com.aulaapi.services;

import br.com.aulaapi.dto.PeopleDTO;
import br.com.aulaapi.entities.People;
import br.com.aulaapi.repositories.PeopleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
public class ServiceSWAPI {
    @Autowired
    PeopleRepository peopleRepository;

    public List<PeopleDTO> searchPeople() {
      List<People> people = peopleRepository.findAll();
      return PeopleDTO.convert(people);
    }

    public People createPeople(People peopleSWAPI) {
        return peopleRepository.save(peopleSWAPI);
    }

    public People updatePeople(People peopleSWAPI) {
        return peopleRepository.save(peopleSWAPI);
    }

    public void deletePeople(@PathVariable Long id) {
        peopleRepository.deleteById(id);
    }
}

