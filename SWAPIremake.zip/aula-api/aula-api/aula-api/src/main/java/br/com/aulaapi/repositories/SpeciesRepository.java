package br.com.aulaapi.repositories;

import br.com.aulaapi.entities.People;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SpeciesRepository extends JpaRepository<People, Long> {
}
