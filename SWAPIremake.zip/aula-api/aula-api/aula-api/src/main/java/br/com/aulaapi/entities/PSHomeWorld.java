package br.com.aulaapi.entities;

import javax.persistence.*;

@Entity(name="PSHOMEWORLD")
public class PSHomeWorld {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="AHOMEWORLD_ID")
    private Long id;


}
