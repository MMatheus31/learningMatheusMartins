package br.com.aulaapi.entities;

import javax.persistence.*;

@Entity(name="PGENDER")
public class PGender {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PGENDER_ID")
    private Integer id;

    @Column(name = "PGENDER_NAME", nullable = false)
    private String name;

    @OneToOne
    @JoinColumn(name ="PEOPLE_ID")
    private People people;
}
