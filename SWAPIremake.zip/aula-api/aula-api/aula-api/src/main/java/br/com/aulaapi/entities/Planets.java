package br.com.aulaapi.entities;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

@Entity(name="PLANETS")
public class Planets {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="PLANETS_ID")
    private Integer id;

    @Column(name="PLANETS_DIAMETER")
    private Float diameter;

    @Column(name="PLANETS_ROTATIONPERIOD")
    private String rotationperiod;

    @Column(name="PLANETS_ORBITALPERIOD")
    private String orbitalperiod;

    @Column(name="PLANETS_GRAVITY", nullable = true)
    private Float gravity;

    @Column(name="PLANETS_POPULATION", nullable = true)
    private Float population;

    @Column(name="PLANETS_CLIMATE")
    private String climate;

    @Column(name="PLANETS_TERRRAIN")
    private String terrain;

    @Column(name="PLANETS_SURFACEWATER")
    private String surfacewater;

    @Column(name="PLANETS_CREATED")
    @DateTimeFormat
    private String planetscreated;

    @Column(name="PLANETS_EDITED")
    @DateTimeFormat
    private String planetsedited;
}
