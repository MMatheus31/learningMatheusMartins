package br.com.aulaapi.dto;

import br.com.aulaapi.entities.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class PeopleDTO {

    private Integer id;
    private String name;
    private Float mass;
    private String peoplecreated;
    private String peopleedited;
    private Set<AEyeColor> eyeColorSWAPI;
    private Set<AHairColor> hairColorSWAPI;
    private Set<ASkinColor> skinColorSWAPI;
    private PGender pGenderSWAPI;
    private PBirthYear birthyear;

    public PeopleDTO(PeopleDTO peopleDTO) {
        this.id = peopleDTO.getId();
        this.name = peopleDTO.getName();
        this.mass = peopleDTO.getMass();
        this.peoplecreated = peopleDTO.getPeoplecreated();
        this.peopleedited = peopleDTO.getPeopleedited();
        this.eyeColorSWAPI = peopleDTO.getEyeColorSWAPI();
        this.hairColorSWAPI = peopleDTO.getHairColorSWAPI();
        this.skinColorSWAPI = peopleDTO.getSkinColorSWAPI();
        this.pGenderSWAPI = peopleDTO.getPGenderSWAPI();
        this.birthyear = peopleDTO.getBirthyear();
    }

    public PeopleDTO(People people) {
    }

    public static List<PeopleDTO> convert(List<People> people){
        return people.stream().map(PeopleDTO::new).collect(Collectors.toList());
    }
}

