package br.com.aulaapi.entities;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

@Entity(name="SPECIESSWAPI")
public class Species {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="SPECIES_ID")
    private Integer id;

    @Column(name="SPECIES_NAME", nullable = false)
    private String nome;

    @Column(name="SPECIES_CLASSIFICATION", nullable = false)
    private String classification;

    @Column(name="SPECIES_DESIGNATION", nullable = false)
    private String designation;

    @Column(name="SPECIES_AVARAJELENGHT")
    private Float avaregelenght;

    @Column(name="SPECIES_AVARAGELIFESPAN")
    private String avaregelifespan;

    @Column(name="SPECIES_LANGUAGE")
    private String language;

    @Column(name="SPECIES_CREATED")
    @DateTimeFormat
    private String speciescreated;

    @Column(name="SPECIES_EDITED")
    @DateTimeFormat
    private String speciesedited;
}

