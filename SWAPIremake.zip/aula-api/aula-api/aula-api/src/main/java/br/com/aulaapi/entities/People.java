package br.com.aulaapi.entities;


import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.beans.ConstructorProperties;
import java.util.List;
import java.util.Set;

@Data
@Entity(name="PEOPLE")
@NoArgsConstructor
public class People {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="PEOPLE_ID", nullable = false)
    private Integer id;

    @Column(name="PEOPLE_NAME", nullable = false)
    private String name;

    @Column(name="PEOPLE_MASS")
    private Float mass;

    @Column(name="PEOPLE_CREATED")
    @DateTimeFormat
    private String peoplecreated;

    @Column(name="PEOPLE_EDITED")
    @DateTimeFormat
    private String peopleedited;

    @OneToMany(mappedBy = "peopleSWAPI", cascade = {CascadeType.ALL})
    private Set<AEyeColor> eyeColorSWAPI;

    @OneToMany(mappedBy = "peopleSWAPI", cascade = {CascadeType.ALL})
    private Set<AHairColor> hairColorSWAPI;

    @OneToMany(mappedBy = "peopleSWAPI", cascade = {CascadeType.ALL})
    private Set<ASkinColor> skinColorSWAPI;

    @OneToOne
    @JoinColumn(name ="PGENDER_AGENDER_ID")
    private PGender pGenderSWAPI;

    @OneToOne
    @JoinColumn(name ="PBIRTHYEAR_PBIRTHYEAR_ID")
    private PBirthYear birthyear;

}


