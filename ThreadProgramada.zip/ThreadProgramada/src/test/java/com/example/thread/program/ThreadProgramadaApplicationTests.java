package com.example.thread.program;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadProgramadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
