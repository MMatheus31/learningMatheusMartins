package com.example.thread.program;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class ThreadProgramada implements Runnable {

    @Override
    public void run() {
        while(true){
            long millis = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date(millis);
            String dateformat = sdf.format(date);

            if(dateformat.equals("08:00:00")){
                System.out.println(dateformat + " - Good Morning!");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else if (dateformat.equals("12:00:00")) {
                System.out.println(dateformat + " - Good Afternoon!");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else if (dateformat.equals("18:00:00")) {
                System.out.println(dateformat + " - Good Night!");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else{
                try{
                    System.out.println(dateformat);
                    Thread.sleep(1000);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }

}

}



//
//    public class ReminderBD extends TimerTask {
//        public void run() {
//            System.out.println(new Date() + " Bom Dia!");
//        }
//    }
//
//    public class ReminderBT extends TimerTask {
//        public void run() {
//            System.out.println(new Date() + " Boa Tarde!");
//        }
//    }
//
//    public class ReminderBN extends TimerTask {
//        public void run() {
//            System.out.println(new Date() + " Boa Noite!");
//        }
//    }
//
//    @Override
//    public void run() {
//
//        Timer timer;
//
//        Calendar calendar = Calendar.getInstance();
//        calendar.set(Calendar.HOUR_OF_DAY, 9);
//        calendar.set(Calendar.MINUTE, 17);
//        calendar.set(Calendar.SECOND, 0);
//        Date timer1 = calendar.getTime();
//
//        timer = new Timer();
//        timer.schedule(new ReminderBD(), timer1);
//
//        Calendar calendar2 = Calendar.getInstance();
//        calendar2.set(Calendar.HOUR_OF_DAY, 12);
//        calendar2.set(Calendar.MINUTE, 0);
//        calendar2.set(Calendar.SECOND, 0);
//        Date timer2 = calendar2.getTime();
//
//        timer = new Timer();
//        timer.schedule(new ReminderBT(), timer2);
//
//        Calendar calendar3 = Calendar.getInstance();
//        calendar3.set(Calendar.HOUR_OF_DAY, 18);
//        calendar3.set(Calendar.MINUTE, 0);
//        calendar3.set(Calendar.SECOND, 0);
//        Date timer3 = calendar3.getTime();
//
//        timer = new Timer();
//        timer.schedule(new ReminderBN(), timer3);
