package com.example.thread.program;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class ThreadProgramada implements Runnable {

    public class ReminderBD extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Bom Dia!");
        }
    }

    public class ReminderBT extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Boa Tarde!");
        }
    }

    public class ReminderBN extends TimerTask {
        public void run() {
            System.out.println(new Date() + " Boa Noite!");
        }
    }

    @Override
    public void run() {

        Timer timer;

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 54);
        calendar.set(Calendar.SECOND, 0);
        Date timer1 = calendar.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBD(), timer1);

        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.HOUR_OF_DAY, 11);
        calendar2.set(Calendar.MINUTE, 54);
        calendar2.set(Calendar.SECOND, 10);
        Date timer2 = calendar2.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBT(), timer2);

        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(Calendar.HOUR_OF_DAY, 11);
        calendar3.set(Calendar.MINUTE, 54);
        calendar3.set(Calendar.SECOND, 20);
        Date timer3 = calendar3.getTime();

        timer = new Timer();
        timer.schedule(new ReminderBN(), timer3);

    }

}
