package com.example.thread.program;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreadProgramadaApplication {

	public static void main(String[] args) {
		ThreadProgramada threadProgramada = new ThreadProgramada();
		Thread thread = new Thread(threadProgramada);
		thread.start();
		SpringApplication.run(ThreadProgramadaApplication.class, args);
	}

}
