package br.com.aulaocore.entities;

import javax.persistence.*;

@Entity(name = "pessoa")
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ID", nullable = false)
    private Integer id;

    @Column(name="NOME", nullable = false)
    private String name;

    @Column(name = "SOBRENOME", nullable = false)
    private String sobrenome;

    public Pessoa() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSobrenome() {
        return sobrenome;
    }


    public Pessoa(Integer id, String name, String sobrenome) {
        this.id = id;
        this.name = name;
        this.sobrenome = sobrenome;
    }
}