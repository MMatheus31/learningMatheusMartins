package br.com.aulaocore.service;

import br.com.aulaocore.entities.Pessoa;
import br.com.aulaocore.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ServiceConsulta {

    @Autowired
    PessoaRepository pessoaRepository;

    private List<Pessoa> pessoaCache;

    public List<Pessoa> PessoaCache(){
        List<Pessoa> servicePessoaCache = reqSearchPessoas();
        return pessoaCache;
    }

    public List<Pessoa> searchPessoas() {
        this.pessoaCache = pessoaRepository.findAll();
        return this.pessoaCache;
    }

    public List<Pessoa> reqSearchPessoas() {
        return pessoaCache;
    }

    public Optional<Pessoa> searchPessoaById(@PathVariable Integer id) {
        return pessoaRepository.findById(id);
    }


//    public List<Pessoa> pessoaCache(){
//        List<String> pessoa = new ArrayList<>();
//        pessoa.equals(this.pessoaList);
//        return this.pessoaList;
//    }




}







//    private EntityManager getEntityManager() {
//        EntityManagerFactory factory = null;
//        EntityManager entityManager = null;
//        try {
//            factory = Persistence.createEntityManagerFactory("PessoaDAO");
//            entityManager = factory.createEntityManager();
//        } finally {
//            factory.close();
//        }
//        return entityManager;
//    }
//
//    public Pessoa consulta(){
//        E


