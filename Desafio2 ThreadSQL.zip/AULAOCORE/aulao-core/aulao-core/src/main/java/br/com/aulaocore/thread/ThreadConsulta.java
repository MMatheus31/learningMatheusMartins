package br.com.aulaocore.thread;

import br.com.aulaocore.controllers.InfoController;
import br.com.aulaocore.entities.Pessoa;
import br.com.aulaocore.service.ServiceConsulta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import javax.persistence.criteria.CriteriaBuilder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class ThreadConsulta implements Runnable{

    InfoController infoController = new InfoController();
    ServiceConsulta serviceConsulta = new ServiceConsulta();
    Pessoa pessoa = new Pessoa();

    public ThreadConsulta(InfoController infoController) {
        this.infoController = infoController;
    }

    public List<Pessoa> srcPessoa(){
        return infoController.searchPessoas();
    }

    public List<Pessoa> srcPessoaCache(){
        return infoController.cachePessoa();
    }


    @Override
    public void run() {
        while (true) {
            long millis = System.currentTimeMillis();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date(millis);
            String dateformat = simpleDateFormat.format(date);

            if(dateformat.equals("16:18:20")){
                srcPessoa();
                srcPessoaCache();
               try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else {
                try{
                 System.out.println(dateformat);
                 System.out.println("Waiting for an appointment time, normally - 08:00AM");
                    Thread.sleep(1000);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }

        }
    }
}
