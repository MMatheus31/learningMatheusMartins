package br.com.aulaocore.controllers;

import br.com.aulaocore.entities.Pessoa;
import br.com.aulaocore.service.ServiceConsulta;
import br.com.aulaocore.thread.ThreadConsulta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.*;

@RestController
@RequestMapping("/desafio2/pessoa")
public class InfoController {

    @Autowired
    ServiceConsulta serviceConsulta;

    @PostConstruct
    public void iniciaThread(){
        ThreadConsulta threadConsulta = new ThreadConsulta(this);
        Thread thread = new Thread(threadConsulta);
        thread.start();
    }
    @GetMapping
    @ResponseBody
    //@Cacheable(value = "Pessoa")
    public List<Pessoa> PessoaCache(){
        List<Pessoa> pCache = serviceConsulta.PessoaCache();
        System.out.println(pCache);
        return pCache;
    }
    @GetMapping("/save/cache")
    @ResponseBody
    //@Cacheable(value = "Pessoa")
    public List<Pessoa> searchPessoas(){
        return serviceConsulta.searchPessoas();
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Optional<Pessoa> searchPessoaById(@PathVariable Integer id){
        Optional<Pessoa> pessoa = serviceConsulta.searchPessoaById(id);
        return serviceConsulta.searchPessoaById(id);
    }

    
}


















//    @GetMapping("/{number}")
//    public String info(@PathParam("number") Integer number1, @PathParam("number") Integer number2) {
//        StringBuffer stringBuffer = new StringBuffer();
//        stringBuffer.append(number1 + "e");
//        if (number1 % 2 == 0) {
//            stringBuffer.append("par");
//        } else {
//            stringBuffer.append("impar");
//        }
//        stringBuffer.append("voce tambem digitou o numero " +  number2);
//        return stringBuffer.toString();
//    }
//
//    @GetMapping("/2")
//    public Map<String, Pessoa> info() {
//
//        List<String> frutas = new ArrayList<>();
//
//        frutas.add("maca");
//        frutas.add("pera");
//        frutas.add("laranja");
//
//        List<Pessoa> pessoas = new ArrayList<>();
//
//        Pessoa pessoa = new Pessoa("Matheus", 18, "M", "Martins");
//        pessoa.setNome("Matheus");
//        pessoa.setIdade(18);
//        pessoa.setSexo("F");
//        pessoa.setSobrenome("Martins");
//        pessoas.add(pessoa);
//
//        pessoa = new Pessoa("Vinicius", 18, "M", "Mineiro");
//        pessoa.setNome("Vinicius");
//        pessoas.add(pessoa);
//
//        pessoa = new Pessoa("Patrcia", 34, "F","Martins");
//        pessoa.setNome("Patricia");
//        pessoa.setSobrenome("Martins");
//        pessoas.add(pessoa);
//

//
//        Set<Pessoa> pessoas1 = new HashSet<>();
//        pessoas.add(pessoa);
//
//        pessoa.setNome("Vinicius");
//        pessoas1.add(pessoa);
//
//        pessoa.setNome("Patricia");
//        pessoa.setSobrenome("Martins");
//        pessoas1.add(pessoa);
//

//
//        Map<String, Pessoa> pessoaMap = new HashMap<>();
//        pessoaMap.put("A", new Pessoa("Matheus", 18, "M", "Martins"));
//        pessoaMap.put("A", new Pessoa("Vinicius", 18, "M", "Mineiro"));
//        pessoaMap.remove("A");
//        return pessoaMap;
//    }
//
//    @GetMapping
//    public void teste3(@PathParam("number1") Integer number1){
//
//        try{
//            int teste = number1;
///        } catch (Exception e){
//            e.printStackTrace();
//        }
//    }

