package br.com.aulaocore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaoCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
